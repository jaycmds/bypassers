<div align="center">
  <h3>✨AIO BYPASSER✨<br></h3>
  <img src="https://raw.githubusercontent.com/TWIST-X7/Aio-Bypasser/main/ico/aio-bypasser.ico">
</div>

<div align="center">
  <h3></h3>
  <h4>Universal + linkvertsie bypasser</h4>

  <img src="https://cdn.discordapp.com/attachments/962389056627548284/967420383127044157/aiobypasser.png">
  <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
</div>

#### Features
- 🟩 + 17 links Supported
- 🟩 Very Fast
- 🟩 Easy to use
##### 🟩 = Done/Working | 🟨 = In development | ⬛️ = Todo | 🟥 = Not Working

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

#### Prerequisites
- Visual Studio Code
- .Net Core SDK
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

#### Setup
### ------------------------------------------First Way---------------------------------------------
1. Download the repository
2. Open `aio_bypasser.sln` with visual studio code
4. Go to tools -> NuGet Package Manager -> Manage NuGet Packages -> Look for `Newtonsoft.Json` -> Select Project -> Install
5. Build The Solution
6. Enjoy
### ------------------------------------------Second Way---------------------------------------------
1. Download The exe in Release By Clicking This : [Download](https://github.com/TWIST-X7/Aio-Bypasser/releases/download/bypasser/aio-bypasser.exe)
2. Run the exe
3. Enjoy
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

### Supported links
| Website       | Working ?      | 
| ------------- | -------------:| 
| linkvertise.com      | ✔ | 
| adf.ly      | ✔     | 
| exe.io/exey.io      | ✔     | 
| sub2unlock.net/sub2unlock.com | ✔     | 
| rekonise.com | ✔      | 
| letsboost.net | ✔      | 
| ph.apps2app.com | ✔     | 
| mboost.me | ✔     | 
| shortconnect.com | ✔     | 
| sub4unlock.com | ✔     | 
| ytsubme.com | ✔      | 
| bit.ly | ✔      | 
| social-unlock.com | ✔      | 
| boost.ink | ✔      | 
| goo.gl | ✔      | 
| shrto.ml | ✔      | 
| t.co | ✔      | 
| tinyurl.com | ✔      | 
| And more... | ✔      | 

#### Credits
- [bypass.vip](https://github.com/bypass-vip) (For The Api)
- [addidix.#0506](https://github.com/addi00000) (For Making the README)

#### Errors?
- Make an [issue](https://github.com/TWIST-X7/Aio-Bypasser/issues)
- Join the [Discord](https://discord.gg/dGCCkkBC7d)
